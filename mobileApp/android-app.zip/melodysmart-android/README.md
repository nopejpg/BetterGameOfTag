# MelodySmart Android

This project contains the MelodySmart sample appication and libraries for Android. It allows any Android 4.3+ device to communicate with BlueCreation's BC118/BC127/BC139 range of products over Bluetooth Low Energy.